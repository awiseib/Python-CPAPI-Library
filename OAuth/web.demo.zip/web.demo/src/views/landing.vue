<template lang="pug">
    div
        p Landing Page
</template>

<script>
    export default  {
        name: 'landing'
    }
</script>

<style>

</style>